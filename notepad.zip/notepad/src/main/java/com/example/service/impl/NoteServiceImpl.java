package com.example.service.impl;

import com.example.service.NoteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.List;

/**
 * @author xiaozhang
 * @createtime 2021-01-15
 * @description
 */
@Service
@Slf4j
public class NoteServiceImpl implements NoteService {
    @Value("${notepad.path}")
    private String filepath;

    private String suffix = ".html";

    private String tempPath = "/templates/init.html";

    /**
     * @author zzzzhang
     * @decription 初始化一个文件
     */
    @Override
    public void initFile(String filename) {
        Path path = Paths.get(filepath + filename + suffix);
        try {
            if (!Files.exists(Paths.get(filepath))) {
                Files.createDirectories(Paths.get(filepath));
            }
            if (!Files.exists(path)) {
                Files.createFile(path);
                ClassPathResource resource = new ClassPathResource(tempPath);
                InputStream inputStream = resource.getInputStream();
                Files.copy(inputStream, path, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void coverFile(String content, String filename){
        Path path = Paths.get(filepath + filename + suffix);
        if(Files.exists(path)){
            try {
                Files.write(path,content.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            log.warn("file not exist");
        }
    }

    @Override
    public List<String> getFile(String filename){
        Path path = Paths.get(filepath + filename + suffix);
        List<String> list = null;
        try {
            list = Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }
}
