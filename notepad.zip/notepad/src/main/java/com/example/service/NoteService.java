package com.example.service;

import java.util.List;

/**
 * @author xiaozhang
 * @createtime 2021-01-15
 * @description
 */
public interface NoteService {
    void initFile(String filename);

    void coverFile(String content, String filename);

    List<String> getFile(String filename);
}
