package com.example.controller;

import com.example.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * @author xiaozhang
 * @createtime 2021-01-15
 * @description
 */
@Controller
public class NoteController {
    @Autowired
    NoteService noteService;

    @GetMapping("/notepad/{file}")
    public void getNotepad(@PathVariable String file, HttpServletResponse response) {
        noteService.initFile(file);
        List<String> list = noteService.getFile(file);
        PrintWriter writer;
        try {
            writer = response.getWriter();
            for (String s : list) {
                writer.write(s);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @PutMapping("/notepad/{file}")
    public void saveNotepad(@PathVariable String file, String content) {
//        noteService.coverFile(content,file);
        if(file.contains("/notepad/")){

        }
        System.out.println(file+content);
    }

    @GetMapping("/test")
    public String test(){
        return "test";
    }
}
