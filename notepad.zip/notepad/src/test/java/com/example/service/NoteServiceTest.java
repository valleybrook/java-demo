package com.example.service;

import com.example.App;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author xiaozhang
 * @createtime 2021-01-15
 * @description
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = App.class)
public class NoteServiceTest {
    @Autowired
    NoteService noteService;
    @Test
    public void createFile(){
//        noteService.initFile("firstTest");
//        noteService.coverFile("123","firstTest");
    }
}
