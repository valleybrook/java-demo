import com.example.UploadApplication;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = UploadApplication.class)
public class Test {
    @org.junit.Test
    public void method(){
        System.out.println(1);
    }
}
