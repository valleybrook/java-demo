package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.util.unit.DataSize;
import org.springframework.util.unit.DataUnit;

import javax.servlet.MultipartConfigElement;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class UploadApplication {
    public static void main(String[] args) {
//        SpringApplication application=new SpringApplication(UploadApplication.class);
//        String osName=System.getProperty("os.name");
//        if(osName.contains("Windows")){
//            application.setAdditionalProfiles("dev");
//        }
//        if(osName.contains("Linux")){
//            application.setAdditionalProfiles("test");
//        }
//        application.run(args);
        SpringApplication.run(UploadApplication.class,args);
    }

    @Bean
    public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory=new MultipartConfigFactory();
        factory.setMaxFileSize(DataSize.of(2, DataUnit.GIGABYTES));
        factory.setMaxRequestSize(DataSize.of(10,DataUnit.GIGABYTES));
        return factory.createMultipartConfig();
    }
}
