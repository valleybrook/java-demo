package com.example.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class EnvProperteis {

    public static String uploadPath;

    public static String mappingPath;

    public static String requestUrl;

    @Value("${sys.file.upload-path}")
    public void setUploadPath(String uploadPath) {
        EnvProperteis.uploadPath = uploadPath;
    }

    @Value("${sys.file.mapping-path}")
    public void setMappingPath(String mappingPath) {
        EnvProperteis.mappingPath = mappingPath;
    }

    @Value("${sys.file.request-url}")
    public void setRequestUrl(String requestUrl) {
        EnvProperteis.requestUrl = requestUrl;
    }
}


