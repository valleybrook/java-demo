package com.example.controller;

import com.example.config.EnvProperteis;
import com.example.entity.FileInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class UploadController {

    private static String uploadPath= EnvProperteis.uploadPath;
    private static String requestUrl=EnvProperteis.requestUrl;

    @GetMapping("/")
    public String home(){
        return "redirect:/index";
    }

    @GetMapping(value = {"/index","/index/{pageNum}/{pageSize}"})
    public String index(Model model,@PathVariable(value = "pageNum",required = false) Integer pageNum,
                        @PathVariable(value = "pageSize",required = false) Integer pageSize){
        if(pageNum==null)
            pageNum=1;
        if(pageSize==null)
            pageSize=5;
        int lastPage;
        List<FileInfo> table = getFileList();
        sortListByTime(table);
        List<FileInfo> collect = table.stream()
                .skip(pageSize * (pageNum - 1))
                .limit(pageSize)
                .collect(Collectors.toList());
        if(table.size()%pageSize==0){
            lastPage=table.size()/pageSize;
        }else {
            lastPage=table.size()/pageSize+1;
        }
        model.addAttribute("table",collect);
        model.addAttribute("firstPage",1);
        model.addAttribute("currentPage",pageNum);
        model.addAttribute("lastPage",lastPage);
        return "index";
    }

    @ResponseBody
    @PostMapping("/file")
    public String uploadFile(@RequestParam("file") MultipartFile file){
        String fileName=file.getOriginalFilename();
        File dest=new File(uploadPath+fileName);
        if(fileName.length()>30)
            return "文件名限制30字符";
        try {
            file.transferTo(dest);
            return "上传成功";
        } catch (IOException e) {
            return "上传失败";
        }
    }

    @ResponseBody
    @GetMapping("/deleteFile")
    public String displayList(String fileName){
        File file=new File(uploadPath+fileName);
        try {
            file.delete();
            return "删除成功";
        }catch (Exception e){
            return "删除失败";
        }
    }

    public static List<FileInfo> getFileList(){
        File file;
        String fileName;
        String fileSize;
        String modifyTime;
        String url;
        File basePath=new File(uploadPath);
        String[] list = basePath.list();
        SimpleDateFormat sm=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<FileInfo> table=new ArrayList<>();
        for(String str:list){
            file=new File(uploadPath+str);
            //name
            fileName=file.getName();
            //size
            fileSize=unitConvert(file.length());
            //time
            modifyTime = sm.format(new Date(file.lastModified()));
            //url
            url=requestUrl+fileName;
            //list
            FileInfo fileInfo=new FileInfo();
            fileInfo.setFileName(fileName);
            fileInfo.setFileSize(fileSize);
            fileInfo.setModifyTime(modifyTime);
            fileInfo.setRequestUrl(url);
            table.add(fileInfo);
        }
        return table;
    }

    public static void sortListByTime(List<FileInfo> list){
        SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Collections.sort(list,(o1,o2)->{
                    Date dt1 = null;
                    Date dt2 = null;
                    try {
                        dt1 = df.parse(o1.getModifyTime());
                        dt2 = df.parse(o2.getModifyTime());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    if(dt1.getTime()>dt2.getTime()){
                        return -1;
                    }else if(dt1.getTime()<dt2.getTime()){
                        return 1;
                    }else {
                        return 0;
                    }
                }
        );
    }

    public static String unitConvert(long length){
        int count=0;
        while(length>1024){
            length=length/1024;
            count++;
        }
        switch (count){
            case 0:return length+"B";
            case 1:return length+"KB";
            case 2:return length+"MB";
            case 3:return length+"GB";
        }
        return "";
    }

    @ResponseBody
    @PostMapping("/file")
    public String uploadFile1(@RequestParam("file") MultipartFile file){
        return null;
    }

}
